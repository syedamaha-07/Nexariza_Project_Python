document.getElementById('addStockForm').addEventListener('submit', function (e) {
    e.preventDefault();
    
    const symbol = document.getElementById('symbol').value;
    const shares = document.getElementById('shares').value;
    const purchase_price = document.getElementById('purchase_price').value;

    fetch('/add_stock', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
            symbol: symbol,
            shares: parseInt(shares),
            purchase_price: parseFloat(purchase_price)
        })
    })
    .then(response => response.json())
    .then(data => {
        alert(data.message);
        document.getElementById('addStockForm').reset();
        trackPortfolio();
    })
    .catch(error => console.error('Error:', error));
});

function trackPortfolio() {
    fetch('/track_portfolio')
    .then(response => response.json())
    .then(data => {
        const portfolioDiv = document.getElementById('portfolio');
        portfolioDiv.innerHTML = '';

        const portfolio = data.portfolio;
        const totalProfitLoss = data.total_profit_loss;

        portfolio.forEach(stock => {
            portfolioDiv.innerHTML += `
                <div>
                    <h3>${stock.symbol}</h3>
                    <p>Shares: ${stock.shares}</p>
                    <p>Purchase Price: ${stock.purchase_price}</p>
                    <p>Current Price: ${stock.current_price}</p>
                    <p>Profit/Loss: ${stock.profit_loss}</p>
                </div>
            `;
        });

        portfolioDiv.innerHTML += `<h2>Total Profit/Loss: $${totalProfitLoss}</h2>`;
    })
    .catch(error => console.error('Error:', error));
}

trackPortfolio();
