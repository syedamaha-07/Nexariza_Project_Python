from flask import flask, jsonify, request 
import requests 
import sqlite3
app = flask(__name__)

# Alpha Vantage API Key
API_KEY = '19IF2DTI55ZWIN2N'

# Function to fetch real-time stock data from Alpha Vantage
def get_stock_price(symbol):
    base_url = 'https://www.alphavantage.co/query'
    params = {
        'function': 'TIME_SERIES_INTRADAY',
        'symbol': symbol,
        'interval': '5min',
        'apikey': API_KEY
    }
    
    response = requests.get(base_url, params=params)
    data = response.json()

    try:
        last_refreshed = list(data['Time Series (5min)'].keys())[0]
        latest_price = float(data['Time Series (5min)'][last_refreshed]['4. close'])
        return latest_price
    except KeyError:
        return None

# Initialize database
def init_db():
    conn = sqlite3.connect('portfolio.db')
    c = conn.cursor()
    c.execute('''
              CREATE TABLE IF NOT EXISTS portfolio
              (symbol TEXT PRIMARY KEY, shares INTEGER, purchase_price REAL)
              ''')
    conn.commit()
    conn.close()

# Add stock to the portfolio
@app.route('/add_stock', methods=['POST'])
def add_stock():
    data = request.json
    symbol = data.get('symbol')
    shares = data.get('shares')
    purchase_price = data.get('purchase_price')

    conn = sqlite3.connect('portfolio.db')
    c = conn.cursor()
    c.execute('INSERT OR REPLACE INTO portfolio (symbol, shares, purchase_price) VALUES (?, ?, ?)',
              (symbol, shares, purchase_price))
    conn.commit()
    conn.close()

    return jsonify({'message': f'Added {shares} shares of {symbol} at {purchase_price} each.'}), 200

# Remove stock from the portfolio
@app.route('/remove_stock', methods=['POST'])
def remove_stock():
    data = request.json
    symbol = data.get('symbol')

    conn = sqlite3.connect('portfolio.db')
    c = conn.cursor()
    c.execute('DELETE FROM portfolio WHERE symbol = ?', (symbol,))
    conn.commit()
    conn.close()

    return jsonify({'message': f'Removed {symbol} from portfolio.'}), 200

# Track and display the portfolio
@app.route('/track_portfolio', methods=['GET'])
def track_portfolio():
    conn = sqlite3.connect('portfolio.db')
    c = conn.cursor()
    c.execute('SELECT * FROM portfolio')
    portfolio = c.fetchall()
    conn.close()

    total_profit_loss = 0
    portfolio_data = []

    for stock in portfolio:
        symbol, shares, purchase_price = stock
        current_price = get_stock_price(symbol)
        if current_price:
            profit_loss = (current_price - purchase_price) * shares
            total_profit_loss += profit_loss
            portfolio_data.append({
                'symbol': symbol,
                'shares': shares,
                'purchase_price': purchase_price,
                'current_price': current_price,
                'profit_loss': round(profit_loss, 2)
            })

    return jsonify({'portfolio': portfolio_data, 'total_profit_loss': round(total_profit_loss, 2)}), 200

if __name__ == '__main__':
    init_db()
    app.run(debug=True)

